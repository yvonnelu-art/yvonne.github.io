import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
try {
  const envText = await fs.readFile(path.join(here, '.env'), 'utf8');
  for (const line of envText.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (match && !process.env[match[1]]) process.env[match[1]] = match[2].replace(/^['\"]|['\"]$/g, '');
  }
} catch {}
const dataDir = process.env.DATA_DIR || path.join(here, 'data');
const casesFile = path.join(dataDir, 'cases.json');
const port = Number(process.env.PORT || 8787);
const clientId = process.env.GOOGLE_CLIENT_ID || '';
const isProduction = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const sessionTtl = 60 * 60 * 24 * 7;
let jwks = { keys: [], expiresAt: 0 };

if (isProduction && (!process.env.SESSION_SECRET || process.env.SESSION_SECRET === 'replace-with-a-long-random-secret')) {
  throw new Error('Set SESSION_SECRET in production.');
}

const send = (res, status, body, headers = {}) => {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', ...headers });
  res.end(JSON.stringify(body));
};

async function readBody(req, limit = 5_000_000) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new Error('Request too large');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks).toString('utf8');
}

async function getSigningKeys() {
  if (Date.now() < jwks.expiresAt && jwks.keys.length) return jwks.keys;
  const response = await fetch('https://www.googleapis.com/oauth2/v3/certs');
  if (!response.ok) throw new Error('Google signing keys are unavailable');
  jwks = await response.json();
  const maxAge = Number(response.headers.get('cache-control')?.match(/max-age=(\d+)/)?.[1] || 3600);
  jwks.expiresAt = Date.now() + maxAge * 1000;
  return jwks.keys;
}

async function verifyGoogleCredential(token) {
  if (!clientId) throw new Error('Google sign-in is not configured');
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Invalid Google credential');
  const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
  const claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  if (header.alg !== 'RS256' || !header.kid) throw new Error('Invalid Google credential');
  const key = (await getSigningKeys()).find(item => item.kid === header.kid);
  if (!key) throw new Error('Unknown Google signing key');
  const publicKey = crypto.createPublicKey({ key, format: 'jwk' });
  const signatureValid = crypto.verify('RSA-SHA256', Buffer.from(`${parts[0]}.${parts[1]}`), publicKey, Buffer.from(parts[2], 'base64url'));
  const issuerValid = ['accounts.google.com', 'https://accounts.google.com'].includes(claims.iss);
  const audienceValid = claims.aud === clientId || (Array.isArray(claims.aud) && claims.aud.includes(clientId));
  if (!signatureValid || !issuerValid || !audienceValid || Number(claims.exp) <= Date.now() / 1000 || !claims.email_verified || !claims.sub || !claims.email) {
    throw new Error('Google account could not be verified');
  }
  return { sub: claims.sub, email: claims.email, name: claims.name || claims.email, picture: claims.picture || '' };
}

function signSession(user) {
  const now = Math.floor(Date.now() / 1000);
  const payload = Buffer.from(JSON.stringify({ ...user, iat: now, exp: now + sessionTtl })).toString('base64url');
  const signature = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function readSession(req) {
  const cookies = Object.fromEntries((req.headers.cookie || '').split(';').map(x => x.trim()).filter(Boolean).map(x => {
    const index = x.indexOf('=');
    return [x.slice(0, index), decodeURIComponent(x.slice(index + 1))];
  }));
  const token = cookies.ae_session || '';
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return null;
  const expected = crypto.createHmac('sha256', sessionSecret).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (expected.length !== supplied.length || !crypto.timingSafeEqual(expected, supplied)) return null;
  try {
    const user = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return user.exp > Date.now() / 1000 ? user : null;
  } catch { return null; }
}

function checkOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}

async function readCases() {
  try { return JSON.parse(await fs.readFile(casesFile, 'utf8')); }
  catch (error) { if (error.code === 'ENOENT') return []; throw error; }
}

let casesWriteQueue = Promise.resolve();
async function writeCases(userCases, user) {
  const operation = casesWriteQueue.then(async () => {
    const previous = await readCases();
    const email = user.email.toLowerCase();
    const owned = new Map(previous.filter(item => String(item.owner || '').toLowerCase() === email).map(item => [String(item.id), item]));
    const nextOwned = [];
    for (const item of userCases) {
      if (!item || item.id == null) continue;
      const id = String(item.id);
      const old = owned.get(id);
      const exists = previous.some(existing => String(existing.id) === id);
      if (old) nextOwned.push({ ...item, owner: item.owner || user.email });
      else if (!exists) nextOwned.push({ ...item, owner: user.email });
    }
    const saved = [...previous.filter(item => String(item.owner || '').toLowerCase() !== email), ...nextOwned];
    await fs.mkdir(dataDir, { recursive: true });
    await fs.writeFile(casesFile, JSON.stringify(saved, null, 2), { mode: 0o600 });
    return nextOwned.filter(item => String(item.owner || '').toLowerCase() === email);
  });
  casesWriteQueue = operation.catch(() => {});
  return operation;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/api/config') return send(res, 200, { clientId, enabled: Boolean(clientId) });
    if (req.method === 'POST' && url.pathname === '/api/auth/google') {
      if (!checkOrigin(req)) return send(res, 403, { error: 'Invalid request origin' });
      const body = JSON.parse(await readBody(req, 50_000));
      const user = await verifyGoogleCredential(body.credential || '');
      const cookie = `ae_session=${encodeURIComponent(signSession(user))}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${sessionTtl}${isProduction ? '; Secure' : ''}`;
      return send(res, 200, { user }, { 'set-cookie': cookie });
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
      if (!checkOrigin(req)) return send(res, 403, { error: 'Invalid request origin' });
      return send(res, 200, { ok: true }, { 'set-cookie': `ae_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${isProduction ? '; Secure' : ''}` });
    }
    if (url.pathname.startsWith('/api/')) {
      const user = readSession(req);
      if (!user) return send(res, 401, { error: 'Please sign in with Google' });
      if (req.method === 'GET' && url.pathname === '/api/me') return send(res, 200, { user });
      if (url.pathname === '/api/cases' && req.method === 'GET') {
        const email = user.email.toLowerCase();
        return send(res, 200, (await readCases()).filter(item => String(item.owner || '').toLowerCase() === email));
      }
      if (url.pathname === '/api/cases' && req.method === 'PUT') {
        if (!checkOrigin(req)) return send(res, 403, { error: 'Invalid request origin' });
        const cases = JSON.parse(await readBody(req));
        if (!Array.isArray(cases)) return send(res, 400, { error: 'Cases must be an array' });
        return send(res, 200, await writeCases(cases, user));
      }
      return send(res, 404, { error: 'Not found' });
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
      const html = await fs.readFile(path.join(here, 'index.html'), 'utf8');
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'strict-origin-when-cross-origin' });
      return res.end(html);
    }
    send(res, 404, { error: 'Not found' });
  } catch (error) {
    const status = error.message === 'Request too large' ? 413 : 400;
    send(res, status, { error: error.message || 'Request failed' });
  }
});

server.listen(port, '0.0.0.0', () => console.log(`AE workspace listening on port ${port}`));

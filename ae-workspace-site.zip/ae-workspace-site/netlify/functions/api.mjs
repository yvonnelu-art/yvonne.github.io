import crypto from 'node:crypto';
import { getStore } from '@netlify/blobs';

const clientId = process.env.GOOGLE_CLIENT_ID || '';
const sessionSecret = process.env.SESSION_SECRET || '';
const sessionTtl = 60 * 60 * 24 * 7;
const casesStore = getStore({ name: 'ae-cases', consistency: 'strong' });
let jwks = { keys: [], expiresAt: 0 };

function json(status, body, headers = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...headers },
  });
}

function checkOrigin(request) {
  const origin = request.headers.get('origin');
  if (!origin) return false;
  try { return new URL(origin).origin === new URL(request.url).origin; }
  catch { return false; }
}

async function getSigningKeys() {
  if (Date.now() < jwks.expiresAt && jwks.keys.length) return jwks.keys;
  const response = await fetch('https://www.googleapis.com/oauth2/v3/certs');
  if (!response.ok) throw new Error('Google signing keys are unavailable');
  jwks = await response.json();
  const maxAge = Number(response.headers.get('cache-control')?.match(/max-age=(\d+)/)?.[1] || 3600);
  jwks.expiresAt = Date.now() + maxAge * 1000;
  return jwks.keys;
}

async function verifyGoogleCredential(token) {
  if (!clientId || !sessionSecret) throw new Error('尚未完成 Google 登入環境設定');
  const parts = String(token).split('.');
  if (parts.length !== 3) throw new Error('Google 登入憑證格式錯誤');
  const header = JSON.parse(Buffer.from(parts[0], 'base64url').toString('utf8'));
  const claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  if (header.alg !== 'RS256' || !header.kid) throw new Error('Google 登入憑證格式錯誤');
  const key = (await getSigningKeys()).find(item => item.kid === header.kid);
  if (!key) throw new Error('Google 登入金鑰已更新，請重試');
  const publicKey = crypto.createPublicKey({ key, format: 'jwk' });
  const signatureValid = crypto.verify('RSA-SHA256', Buffer.from(`${parts[0]}.${parts[1]}`), publicKey, Buffer.from(parts[2], 'base64url'));
  const issuerValid = ['accounts.google.com', 'https://accounts.google.com'].includes(claims.iss);
  const audienceValid = claims.aud === clientId || (Array.isArray(claims.aud) && claims.aud.includes(clientId));
  if (!signatureValid || !issuerValid || !audienceValid || Number(claims.exp) <= Date.now() / 1000 || !claims.email_verified || !claims.sub || !claims.email) {
    throw new Error('Google 帳號驗證失敗');
  }
  return { sub: claims.sub, email: claims.email, name: claims.name || claims.email, picture: claims.picture || '' };
}

function signSession(user) {
  const now = Math.floor(Date.now() / 1000);
  const payload = Buffer.from(JSON.stringify({ ...user, iat: now, exp: now + sessionTtl })).toString('base64url');
  const signature = crypto.createHmac('sha256', sessionSecret).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function readSession(request) {
  if (!sessionSecret) return null;
  const cookies = Object.fromEntries((request.headers.get('cookie') || '').split(';').map(x => x.trim()).filter(Boolean).map(x => {
    const index = x.indexOf('=');
    return [x.slice(0, index), decodeURIComponent(x.slice(index + 1))];
  }));
  const [payload, signature] = (cookies.ae_session || '').split('.');
  if (!payload || !signature) return null;
  const expected = crypto.createHmac('sha256', sessionSecret).update(payload).digest();
  let supplied;
  try { supplied = Buffer.from(signature, 'base64url'); } catch { return null; }
  if (expected.length !== supplied.length || !crypto.timingSafeEqual(expected, supplied)) return null;
  try {
    const user = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return user.exp > Date.now() / 1000 ? user : null;
  } catch { return null; }
}

async function readCases() {
  const entry = await casesStore.getWithMetadata('all-cases', { type: 'json', consistency: 'strong' });
  return entry ? { cases: Array.isArray(entry.data) ? entry.data : [], etag: entry.etag } : { cases: [], etag: null };
}

async function writeCases(userCases, user) {
  const email = user.email.toLowerCase();
  for (let attempt = 0; attempt < 8; attempt++) {
    const { cases: previous, etag } = await readCases();
    const owned = new Map(previous.filter(item => String(item.owner || '').toLowerCase() === email).map(item => [String(item.id), item]));
    const nextOwned = [];
    for (const item of userCases) {
      if (!item || item.id == null) continue;
      const id = String(item.id);
      const old = owned.get(id);
      const exists = previous.some(existing => String(existing.id) === id);
      if (old) nextOwned.push({ ...item, owner: item.owner || user.email });
      else if (!exists) nextOwned.push({ ...item, owner: user.email });
    }
    const saved = [...previous.filter(item => String(item.owner || '').toLowerCase() !== email), ...nextOwned];
    const result = etag
      ? await casesStore.setJSON('all-cases', saved, { onlyIfMatch: etag })
      : await casesStore.setJSON('all-cases', saved, { onlyIfNew: true });
    if (result.modified) return nextOwned.filter(item => String(item.owner || '').toLowerCase() === email);
    await new Promise(resolve => setTimeout(resolve, 20 * (attempt + 1)));
  }
  throw new Error('資料同步忙碌中，請再試一次');
}

export default async function handler(request) {
  const url = new URL(request.url);
  const path = url.pathname;
  try {
    if (request.method === 'GET' && path === '/api/config') {
      return json(200, { clientId, enabled: Boolean(clientId && sessionSecret) });
    }
    if (request.method === 'POST' && path === '/api/auth/google') {
      if (!checkOrigin(request)) return json(403, { error: '無效的請求來源' });
      const body = await request.json();
      const user = await verifyGoogleCredential(body.credential || '');
      const secure = url.protocol === 'https:' ? '; Secure' : '';
      return json(200, { user }, { 'set-cookie': `ae_session=${encodeURIComponent(signSession(user))}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${sessionTtl}${secure}` });
    }
    if (request.method === 'POST' && path === '/api/auth/logout') {
      if (!checkOrigin(request)) return json(403, { error: '無效的請求來源' });
      const secure = url.protocol === 'https:' ? '; Secure' : '';
      return json(200, { ok: true }, { 'set-cookie': `ae_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secure}` });
    }

    if (!path.startsWith('/api/')) return json(404, { error: '找不到頁面' });
    const user = readSession(request);
    if (!user) return json(401, { error: '請先使用 Google 帳號登入' });
    if (request.method === 'GET' && path === '/api/me') return json(200, { user });
    if (request.method === 'GET' && path === '/api/cases') {
      const email = user.email.toLowerCase();
      const { cases } = await readCases();
      return json(200, cases.filter(item => String(item.owner || '').toLowerCase() === email));
    }
    if (request.method === 'PUT' && path === '/api/cases') {
      if (!checkOrigin(request)) return json(403, { error: '無效的請求來源' });
      const body = await request.text();
      if (Buffer.byteLength(body, 'utf8') > 5_000_000) return json(413, { error: '案件資料太大' });
      const cases = JSON.parse(body);
      if (!Array.isArray(cases)) return json(400, { error: '案件資料格式錯誤' });
      return json(200, await writeCases(cases, user));
    }
    return json(404, { error: '找不到 API' });
  } catch (error) {
    return json(400, { error: error.message || '請求失敗' });
  }
}

export const config = {
  path: ['/api/config', '/api/auth/google', '/api/auth/logout', '/api/me', '/api/cases'],
};

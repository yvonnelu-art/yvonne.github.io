# VS MEDIA AE 工作台

## 部署到現有 Netlify 網址

本版本使用 Netlify Functions 處理 Google 登入與案件 API，並用 Netlify Blobs 保存共用案件資料。部署需要從 Git 儲存庫建置；只上傳 HTML 檔不會啟用登入和資料保存。

1. 把本資料夾的檔案放進 GitHub 儲存庫。
2. 在 Netlify 既有網站的部署設定中連結此儲存庫，讓它部署這份網站程式。確認 Build command 是 `npm run build`、Publish directory 是 `public`；Functions directory 由 `netlify.toml` 設定為 `netlify/functions`。
3. 在 Netlify 的環境變數設定中新增：
   - `GOOGLE_CLIENT_ID`：Google Cloud 網頁應用程式用戶端 ID。
   - `SESSION_SECRET`：至少 32 bytes 的隨機密碼，只存放在 Netlify 環境變數中。
   請讓變數可供 Functions 使用，儲存後重新部署。
4. 在 Google Cloud 的同一個 OAuth 用戶端，將以下網址加入「已授權的 JavaScript 來源」：
   `https://comfy-lokum-1a2f84.netlify.app`
5. 測試期間，把 AE 的 Google 帳號加入 Google Auth Platform 測試使用者。每位 AE 從該網址登入後，只會看到自己負責的案件。

Netlify Blobs 會跨網站部署保存資料。正式使用前，請在 Netlify 後台確認 Data & Storage > Blobs 已可用，並留意方案使用額度。

## 本機預覽

直接開啟 `index.html` 可預覽畫面，但不會連線至 Google 登入或雲端案件資料。若要在本機測試伺服器版，可複製 `.env.example` 為 `.env`、填入 `GOOGLE_CLIENT_ID`，再執行 `node server.mjs` 並開啟 `http://localhost:8787`。
